'''import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

df = pd.read_csv("auto-mpg.csv")
df["horsepower"] = df["horsepower"].replace("?",np.nan)
df["horsepower"] = pd.to_numeric(df["horsepower"])
df["horsepower"] = df["horsepower"].fillna(df["horsepower"].mean())
X = df.select_dtypes(include =['int64', 'float64'])
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
pca = PCA(n_components = 2)
X_pca = pca.fit_transform(X_scaled)
print("Original Shape:",X.shape)
print("Reduced shape after PCA:", X_pca.shape)
'''

import pandas as pd
df = pd.read_csv("airlines.csv")
correlation = df.corr()
print("Correlation Matrix")
print(correlation)
