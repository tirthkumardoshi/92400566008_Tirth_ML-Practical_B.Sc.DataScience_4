import pandas as pd
#CSV File
df1 = pd.read_csv("airlines.csv")
print("CSV Data:")
print(df1.head())

#Text File
df1 = pd.read_csv("airlines.txt",delim_whitespace = True)
print("Text File:")
print(df2.head())

#Json File
df3 = pd.read_json("airlines.json")
print("Json File:")
print(df3.head())

#XML File
df4 = pd.read_xml("airlines.xml")
print("XML File:")
print(df4.head())
