import pandas as pd
import numpy as np
ds= pd.read_csv("auto-mpg.csv")
print("Missing Value")
print(ds.isnull().sum())
ds = ds.dropna()
print("After Removing Null Values:")
print(ds.shape)
