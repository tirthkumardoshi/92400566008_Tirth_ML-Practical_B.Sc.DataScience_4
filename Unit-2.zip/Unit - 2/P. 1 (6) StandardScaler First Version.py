import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

df = pd.read_csv("auto-mpg.csv")
df["hoursepower"] = df["horsepower"].replace("?",np.nan)
df["hoursepower"] = pd.to_numeric(df["horsepower"])
df["hoursepower"] = df["horsepower"].fillna(df["horsepower"].mean())
x = df.select_dtypes(inclued=['int64', 'float64']).drop('mpg',axis = 1)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
pca = PCA(n_components = 2)
X_pca = pca.fit_transform(X_scaled)
print("Original Shape:",X.shape)
print("Reduced shape after PCA:", X_pca.shape)
