# First Version
'''import pandas as pd
from sklearn.preprocessing import LabelEncoder

ds = pd.read_csv("airlines.csv")
lable_enc = LabelEncoder ()

ds["Callsign_encoded"] = lable_enc.fit_transform(ds["Callsign"])
print("Encoded Data (Callsign column):\n")
print(ds[["Callsign","Callsign_encoded"]].head(10))
'''
# Second Version
import pandas as pd
df = pd.read_csv("airlines.csv")
df_encoded = pd.get_dummies(df,columns = ["Callsign"])
print("one-Hot Encoded Data:\n")
print(df_encoded.head())

