import pandas as pd
pd.set_option('display.max_columns',None)
pd.set_option('display.width',2000)
pd.set_option('display.expand_frame_repr',False)

ds_csv = pd.read_csv("airlines.csv")

print("CSV Data:")

print(ds_csv.head())

print(ds_csv.head(10).to_string())

print("\n Column names:")

print(ds_csv.columns)
