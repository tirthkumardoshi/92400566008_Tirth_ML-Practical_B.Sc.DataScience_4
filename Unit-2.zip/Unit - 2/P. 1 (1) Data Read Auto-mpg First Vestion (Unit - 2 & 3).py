import pandas as pd
ds_csv = pd.read_csv("auto-mpg.csv")
print("CSV Data:")
print(ds_csv.head())
print(ds_csv.head(10).to_string())
print("\n Column names:")
print(ds_csv.columns)
