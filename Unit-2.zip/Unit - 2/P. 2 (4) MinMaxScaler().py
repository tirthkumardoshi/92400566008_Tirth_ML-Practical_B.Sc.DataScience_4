import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
df = pd.read_csv("airlines.csv")
numeric_cols = df.select_dtypes(include=['int64','float64'])
scaler = MinMaxScaler()
df[numeric_cols.columns] = scaler.fit_transform(numeric_cols)
print("rescaled Data:")
print(df.head())
