# First Version
'''import pandas as pd
from sklearn.preprocessing import LabelEncoder

ds = pd.read_csv("auto-mpg.csv")
lable_enc = LabelEncoder ()

ds["origin_encoded"] = lable_enc.fit_transform(ds["origin"])
print("Encoded Data (origin column):\n")
print(ds[["origin","origin_encoded"]].head(10))
'''
# Second Version
import pandas as pd
df = pd.read_csv("auto-mpg.csv")
df_encoded = pd.get_dummies(df,columns = ["origin"])
print("one-Hot Encoded Data:\n")
print(df_encoded.head())
