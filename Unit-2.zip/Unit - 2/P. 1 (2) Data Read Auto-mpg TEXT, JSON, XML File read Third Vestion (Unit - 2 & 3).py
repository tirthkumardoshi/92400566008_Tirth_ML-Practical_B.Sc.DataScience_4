import pandas as pd
#CSV File
df1 = pd.read_csv("auto-mpg.csv")
print("CSV Data:")
print(df1.head())

#Text File
df1 = pd.read_csv("auto-mpg.txt",delim_whitespace = True)
print("Text File:")
print(df2.head())

#Json File
df3 = pd.read_json("auto-mpg.json")
print("Json File:")
print(df3.head())

#XML File
df4 = pd.read_xml("auto-mpg.xml")
print("XML File:")
print(df4.head())
