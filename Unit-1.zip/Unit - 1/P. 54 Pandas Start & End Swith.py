import pandas as pd
s = pd.Series(['apple'])
print(s.str.startswith('a'))
print(s.str.endswith('e'))
