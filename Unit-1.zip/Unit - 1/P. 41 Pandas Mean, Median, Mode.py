import pandas as pd
df = pd.DataFrame({'A':[2,4,6]})
print(df.mean())
print(df.median())
print(df.mode())
