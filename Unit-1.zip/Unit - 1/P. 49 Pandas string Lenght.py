import pandas as pd
s = pd.Series(["hello"])
print(s.str.len())
