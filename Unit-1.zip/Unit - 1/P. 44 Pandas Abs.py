import pandas as pd
df = pd.DataFrame({'A':[-5,-2,3]})
print(df.abs())
