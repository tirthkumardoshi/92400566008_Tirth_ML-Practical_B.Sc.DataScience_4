import numpy as np
arr = np.array([5, 10, 2, 8])
print("Minimum:",np.amin(arr))
print("Maximum:",np.amax(arr))
