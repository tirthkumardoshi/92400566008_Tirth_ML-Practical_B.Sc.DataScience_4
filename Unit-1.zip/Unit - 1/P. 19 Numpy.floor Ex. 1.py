import numpy as np
arr = np.array([1.9,2.5,3.1])
print(np.floor(arr))
