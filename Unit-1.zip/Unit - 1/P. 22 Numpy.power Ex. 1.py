import numpy as np
a = np.array([2, 3, 4])
print(np.power(a,2))
