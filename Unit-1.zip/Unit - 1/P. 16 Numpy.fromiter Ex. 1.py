import numpy as np
iterable = range(5)
a = np.fromiter(iterable, dtype=int)
print(a)
