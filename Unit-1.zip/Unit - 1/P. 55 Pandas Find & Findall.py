import pandas as pd
s = pd.Series(['apple'])
print(s.str.find('p'))
print(s.str.findall('p'))
