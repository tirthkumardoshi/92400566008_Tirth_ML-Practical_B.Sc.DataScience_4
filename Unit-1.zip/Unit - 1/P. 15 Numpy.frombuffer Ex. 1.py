import numpy as np
s = b"Hello World"
a = np.frombuffer(s, dtype='S1')
print(a)
c = a.astype(str)
print(c)
