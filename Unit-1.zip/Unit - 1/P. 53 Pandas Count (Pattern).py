import pandas as pd
s = pd.Series(["apple"])
print(s.str.count('p'))
