import pandas as pd
df = pd.DataFrame({'A':[1,9,5,2,8,3,6,4,7]})
print(df.min())
print(df.max())
