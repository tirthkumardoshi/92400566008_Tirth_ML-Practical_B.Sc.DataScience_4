import pandas as pd
df = pd.DataFrame({'A': [1,2,None]})
print(df.count())
