import pandas as pd
df = pd.DataFrame({'A':[1,2,3,4,5]})
print(df.head(3))
#print(df.tail(2))
